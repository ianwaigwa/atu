*****************************************************************************************************
Credits: We give thanks to God almighty for making this project happen 
and secondly we give thanks to Mr. Wisdom Torgby his support to this project.

Thank You ATU.
============================================================================================
============================================================================================
Student Login Details
----------------------------
User ID: 01172649D
Password: teeka
---------------------
User ID: 01171056D
Password: bob123
----------------------------
User ID: 01161055D
Password: zzzzz
--------------------
User ID: 01171054D
Password: 12345
-----------------
User ID: 01171100D
Password: test123456
-----------------
User ID: 01171511D
Password: bril
-----------------
User ID: 011733832D
Password: robert123

User ID: 01172006D
Password: atinka
=================================================================================================
=================================================================================================
Admin Login Details
------------------------------
User ID: 01171000D xxxxxx
Password: test123456 xxxx

User ID: 01151000D
Password: test123

User ID: 01161000D
Password: liaison123

User ID: 01131000D
Password: try123

User ID: 01161000D
Password: admin123456

************************************************************************************************************

$sql = "SELECT count(id) AS total FROM tbl_test";
$results = mysqli_query($conn, $sql);
$val = msqli_fetch_assoc($results);

https://docs.google.com/forms/d/19SateCyFAWs2OHgSEfAphyropAvisAbASNQqzr9MNoM/edit#responses












                    
                   